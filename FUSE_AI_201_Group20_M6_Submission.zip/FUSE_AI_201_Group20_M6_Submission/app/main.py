"""Optional FastAPI serving layer for the NSL-KDD model."""
from pathlib import Path
import sys
from typing import Any
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from src.predict import FEATURES, predict_records
app = FastAPI(title="AI-Based Network Intrusion Detection API", version="1.0.0", description="Educational API for a saved NSL-KDD intrusion-detection model.")
class PredictionRequest(BaseModel):
    records: list[dict[str, Any]] = Field(..., min_length=1, description="Records with all 41 NSL-KDD features")
@app.get('/health')
def health(): return {"status":"ok", "model":"NSL-KDD Random Forest pipeline", "mode":"prototype"}
@app.post('/predict')
def predict(request: PredictionRequest):
    try:
        frame = pd.DataFrame(request.records)
        missing = [c for c in FEATURES if c not in frame.columns]
        if missing: raise HTTPException(status_code=422, detail={"missing_features": missing})
        result = predict_records(frame)
        return {"count":len(result), "predictions":result.to_dict(orient="records")}
    except HTTPException: raise
    except Exception as exc: raise HTTPException(status_code=400, detail=f"Prediction input could not be processed: {exc}")
