"""Local Streamlit demo for the NSL-KDD intrusion-detection prototype."""
from pathlib import Path
import sys, json, io
import pandas as pd
import streamlit as st
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from src.predict import FEATURES, predict_records
st.set_page_config(page_title="AI Network Intrusion Detection", page_icon="🛡️", layout="wide")
st.title("AI-Based Network Intrusion Detection")
st.caption("FUSE-AI-201 · Group 20 · Local educational prototype using NSL-KDD")
st.warning("This is a learning prototype, not a live network sensor or production security control. Do not automatically block traffic based on its predictions. NSL-KDD is a benchmark dataset, not current live traffic.")
with st.expander("How it works", expanded=True):
    st.markdown("1. Load the included sample CSV or upload a CSV with all **41 NSL-KDD input features**.\n2. The saved preprocessing + Random Forest pipeline predicts each row.\n3. Review labels/scores and download the output.")
sample_path = ROOT / "sample_input.csv"
a, b = st.columns(2)
with a:
    if st.button("Load included sample CSV", use_container_width=True): st.session_state["sample_loaded"] = True
with b: uploaded = st.file_uploader("Upload feature CSV", type=["csv"])
if uploaded is not None:
    try: data = pd.read_csv(uploaded)
    except Exception as exc: st.error(f"Could not read CSV: {exc}"); st.stop()
elif st.session_state.get("sample_loaded"):
    data = pd.read_csv(sample_path)
else: data = None
if data is None:
    st.info("Load the sample or upload a CSV to begin.")
else:
    st.subheader("Input preview")
    st.write(f"Rows: **{len(data):,}** · Columns: **{len(data.columns):,}**")
    st.dataframe(data.head(10), use_container_width=True)
    missing = [c for c in FEATURES if c not in data.columns]
    if missing: st.error(f"Missing {len(missing)} required feature(s): {', '.join(missing)}")
    elif data.empty: st.error("The CSV contains no rows.")
    elif st.button("Run intrusion prediction", type="primary"):
        try:
            result = predict_records(data)
            combined = pd.concat([data.reset_index(drop=True), result], axis=1)
            n_anomaly = int((result.predicted_label == "anomaly").sum())
            c1,c2,c3 = st.columns(3); c1.metric("Records analyzed", f"{len(result):,}"); c2.metric("Predicted anomalies", f"{n_anomaly:,}"); c3.metric("Predicted normal", f"{len(result)-n_anomaly:,}")
            st.subheader("Prediction results"); st.dataframe(combined, use_container_width=True)
            st.download_button("Download predictions CSV", combined.to_csv(index=False).encode(), "nsl_kdd_predictions.csv", "text/csv")
            st.caption("Anomaly probability is a model score, not proof of malicious intent. Investigate alerts using independent security evidence.")
        except Exception as exc: st.error(f"Prediction failed: {exc}")
metrics_path = ROOT / "reports" / "evaluation_results.json"
if metrics_path.exists():
    st.divider(); st.subheader("Reported evaluation context")
    st.json(json.loads(metrics_path.read_text(encoding="utf-8")))
st.caption("Privacy: do not upload confidential production traffic or sensitive logs to this educational demo.")
