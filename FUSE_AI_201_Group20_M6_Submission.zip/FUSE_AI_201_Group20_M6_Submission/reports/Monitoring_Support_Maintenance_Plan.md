# Monitoring, Support and Maintenance Plan

## Scope and current status
This is a local educational prototype using the NSL-KDD benchmark and a saved scikit-learn preprocessing/model pipeline. It does not inspect live packets, connect to a SOC/SIEM, or automatically block traffic. No production monitoring service is running; the following is a proposed operational plan.

## Monitoring signals
- **Model quality:** When analyst-confirmed labels become available, calculate precision, recall, F1, false-positive/false-negative rates, and confusion matrices by attack family where possible.
- **Operational health:** Record request volume, latency, exceptions, model version, and successful/failed requests.
- **Prediction/data drift:** Compare incoming feature and anomaly-score distributions with reference data. Consider Kolmogorov–Smirnov tests for numeric features and chi-squared tests for categorical features; investigate meaningful shifts rather than treating every significant result as an incident.
- **Alerting:** Establish thresholds with security owners. Initially notify an analyst; never automatically block based only on a drift signal or model prediction.

## Error handling and support
1. Validate all 41 expected features and parse inputs safely.
2. Return clear client errors for missing/malformed fields; log request identifiers and exception classes, not credentials or unnecessary raw traffic.
3. Monitor service health and dependencies. Maintain an owner, severity/escalation path, runbook, rollback steps, and incident log.
4. Reproduce defects with sanitized samples, add regression tests, review fixes, and document releases.

## Retraining and model updates
- Collect new, authorized, representative telemetry and analyst-confirmed labels.
- Version data and code; record Python/library versions, parameters, random seeds, metrics, and model artifacts. MLflow is a suitable future experiment-tracking option, but is not currently configured as a tracking server.
- Tune/select candidates using a validation split or cross-validation within training data. Reserve an untouched test set for final evaluation.
- Compare against the current model and a simple baseline, paying particular attention to false negatives and attack-family performance.
- Promote only after review, tests, and approval. Keep the previous model for rollback. Retrain on a planned cadence or confirmed degradation; do not blindly train on unreviewed data.

## Security and responsible use
- Store credentials in environment variables or a secrets manager; never commit secrets.
- Before external deployment, add TLS, authentication, rate limiting, least-privilege access, and protected logs.
- Minimize and protect network data; define retention and access policies.
- Treat model output as triage support, not proof of malicious intent. Require human review for high-impact actions.
- Evaluate both false positives and false negatives, document benchmark limitations, and test against contemporary authorized data before operational use.

## Proposed maintenance schedule
| Frequency | Activity | Evidence |
|---|---|---|
| Each release | Automated tests, dependency review, version tag, rollback check | Test report and release notes |
| Weekly if deployed | Health, errors, latency, volume, score distribution | Monitoring summary |
| Monthly | Drift and alert review; error analysis where labels exist | Drift/performance report |
| Quarterly or on confirmed degradation | Candidate retraining and validation | Experiment record and model-card update |
| After an incident | Root-cause review, regression tests, runbook update | Incident/postmortem record |

## Critical measured limitation
On the supplied NSL-KDD test split, Random Forest recall was approximately **61.68%**; **4,917 anomalies were classified as normal**. This is a material miss rate. The model is not production-ready. Threshold analysis, validation-only model selection, contemporary data, and independent security testing are needed before real deployment.
