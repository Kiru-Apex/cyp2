# Model Card — NSL-KDD Intrusion Detection Prototype

- **Project/team:** AI-Based Network Intrusion Detection System Using Machine Learning; FUSE-AI-201 Group 20.
- **Model:** scikit-learn preprocessing pipeline + Random Forest classifier.
- **Intended use:** Educational demonstration and preliminary anomaly triage on records matching the NSL-KDD schema.
- **Out-of-scope:** Production traffic blocking, autonomous incident response, or claims of reliable detection on current traffic without independent validation.
- **Data:** Existing NSL-KDD benchmark train/test files; not team-generated synthetic data and not live traffic or private organizational logs.
- **Target:** `normal` vs `anomaly` (all non-normal attack labels grouped as anomaly).
- **Inputs:** 41 NSL-KDD connection features: 3 categorical (`protocol_type`, `service`, `flag`) and 38 numeric. `difficulty_level` is excluded.
- **Preprocessing:** Numeric median imputation; categorical most-frequent imputation and one-hot encoding with unknown categories ignored.
- **Test split:** Supplied official NSL-KDD test split (22,544 records).
- **Reported results:** Accuracy 77.03%; precision 96.80%; recall 61.68%; F1 75.35%.
- **Confusion matrix:** Actual rows / predicted columns, order normal then anomaly: `[[9449, 262], [4917, 7916]]`. Thus 4,917 anomalies were missed as normal and 262 normal records were flagged as anomalies.
- **Evaluation caveat:** The earlier model comparison used the supplied test split for comparison and reporting. For a stronger final estimate, tune/select on validation data or cross-validation within training data, then evaluate once on an untouched test set.
- **Limitations:** Benchmark age; binary aggregation hides attack-family differences; recall may be insufficient for security use; current network behavior may differ; probability scores may need calibration.
- **Safeguards:** Human review, alert-only mode, privacy controls, current-data validation, and rollback.
- **Future work:** Better train/validation/test separation, threshold tuning, attack-family analysis, authorized current data, MLflow tracking, API security, drift reports, and independent security review.
