# FUSE-AI 201 Group 20 — Module 5/Implementation Assignment Report

## Project title
**AI-Based Network Intrusion Detection System Using Machine Learning**

**Domain:** Cybersecurity / Network Security  
**Dataset:** NSL-KDD, supplied course archive  
**Group members:** Add only members who actually participated  
**Submission date:** October 2026

## 1. Refine the problem
The project investigates whether supervised machine learning can classify network connection records as **normal** or **anomalous**. Intended users are cybersecurity analysts and network administrators. Inputs are 41 connection features. Outputs are a binary prediction and, where supported, a probability/score. The prototype is a decision-support demonstration, not an automated network-blocking system.

## 2. Define the AI solution
The baseline is **Logistic Regression** with class weighting. The candidate model is a **Random Forest classifier** with class weighting. Both use a preprocessing pipeline that imputes missing values and one-hot encodes the categorical fields `protocol_type`, `service`, and `flag`. The difficulty-level column is excluded because it is a benchmark annotation rather than an operational input feature. Random Forest was selected as the candidate because it can capture nonlinear relationships in structured/tabular data and does not require numerical feature scaling.

## 3. Prepare the data
The supplied `KDDTrain+.txt` and `KDDTest+.txt` files were used with the standard 41 NSL-KDD feature names, plus label and difficulty-level columns. The difficulty-level field was removed from model inputs. Labels were mapped to binary targets: `normal` = 0; any non-normal attack label = 1. The official train/test files were retained rather than randomly mixing them, preserving the dataset's provided evaluation split.

- Training records: **125,973**
- Test records: **22,544**
- Input features: **41**
- Categorical features: **protocol_type, service, flag**
- Numeric features: **38**
- Missing feature values in training data: **0**
- Duplicate training rows across the 41 input features: **16**

Categorical values not seen during training are handled using `OneHotEncoder(handle_unknown="ignore")`. Median imputation is configured for numeric features, and most-frequent imputation for categorical features. No missing feature values were observed in the training input during this run, but the pipeline still includes imputation for robustness.

## 4. Explore the data
The target distribution is:
- Training: **67,343 normal** and **58,630 anomalous** records.
- Test: **9,711 normal** and **12,833 anomalous** records.

The data is not perfectly balanced, so accuracy alone is insufficient. Precision, recall, F1-score, and the confusion matrix are reported. The dataset is a historical benchmark and may not represent current production network traffic; this limits generalization claims.

## 5. Build a baseline model
Logistic Regression was trained as the reference model. Class weighting was used to reduce the impact of class imbalance. The model was evaluated on the supplied `KDDTest+` split.

| Metric | Logistic Regression baseline |
|---|---:|
| Accuracy | 68.64% |
| Precision | 88.92% |
| Recall | 51.31% |
| F1-score | 65.07% |

Training time in this run: **7.80 seconds** (hardware and environment dependent).

## 6. Improve the model
A Random Forest with 120 trees and `class_weight="balanced_subsample"` was trained as the improved candidate. The same official test split and binary labels were used for a fair comparison.

| Metric | Logistic Regression | Random Forest |
|---|---:|---:|
| Accuracy | 68.64% | 77.03% |
| Precision | 88.92% | 96.80% |
| Recall | 51.31% | 61.68% |
| F1-score | 65.07% | 75.35% |

Training time in this run: **8.38 seconds** (hardware and environment dependent). The measured comparison, rather than model complexity alone, should determine which model is preferred.

## 7. Evaluate the model
The Random Forest test confusion matrix (rows = actual class; columns = predicted class) is:

| | Predicted normal | Predicted anomaly |
|---|---:|---:|
| Actual normal | 9,449 | 262 |
| Actual anomaly | 4,917 | 7,916 |

- **False positives:** 262 normal records classified as anomalies. These may increase analyst workload.
- **False negatives:** 4,917 anomalous records classified as normal. These are important because they represent missed anomalies.
- **Strength:** The pipeline provides a repeatable comparison on a fixed test set.
- **Limitation:** NSL-KDD is a benchmark dataset and does not guarantee detection of modern or previously unseen attacks in live networks.

See `reports/confusion_matrix.png`, `reports/model_comparison.png`, and `reports/evaluation_results.json`.

## 8. Test the solution
The end-to-end pipeline is tested below. Run the notebook or Python script to reproduce the checks.

1. **Valid known record:** Use a row from the supplied test data; the pipeline should return a prediction without preprocessing errors.
2. **Categorical value unseen during training:** The encoder is configured to ignore unknown categories rather than fail.
3. **Missing feature value:** The imputation pipeline should handle a missing numeric or categorical value.
4. **Malformed input:** Inputs with missing required columns should be rejected with a clear error by the prediction helper.
5. **Output check:** The prediction must be one of `normal` or `anomaly`; probability output is generated when the model supports it.

The supplied `src/predict.py` provides a reusable prediction function and command-line demo. This is a prototype workflow and should not be connected to production network controls without additional security testing and validation.

## Conclusions
The project implements a reproducible binary intrusion-detection workflow, from data preparation and EDA through baseline training, candidate-model comparison, evaluation, and test-case checks. Final model choice should be based on the reported test metrics and the team's priorities for missed anomalies versus false alarms. Before submission, the group should insert only participating member names, verify that the notebook runs in the intended environment, and ensure that all members understand and can explain the results.
