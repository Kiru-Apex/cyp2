# Capstone Video Presentation Script (target 8–9 minutes; maximum 10 minutes)

## 0:00–0:45 — Problem and solution
“Hello, this is our FUSE-AI-201 Group 20 project: AI-Based Network Intrusion Detection Using Machine Learning. Network defenders need to identify suspicious connection activity, but missed attacks and false alarms both matter. We built a prototype that classifies NSL-KDD connection records as normal or anomalous.”
**Show:** Title and flow: CSV/connection features → preprocessing pipeline → Random Forest → prediction and score.

## 0:45–1:45 — Dataset and preparation
“We used the NSL-KDD benchmark training and test files. The input contains 41 features, including protocol type, service, flag, and traffic statistics. Normal is 0 and all non-normal attack labels are grouped as anomaly. We excluded difficulty_level from the inputs. Numeric values use median imputation; categorical features use most-frequent imputation and one-hot encoding.”
**Show:** Notebook dataset summary or report.

## 1:45–3:00 — Model and evaluation
“We compared Logistic Regression with Random Forest. On the supplied test split, Random Forest achieved 77.03% accuracy, 96.80% precision, 61.68% recall, and 75.35% F1. The confusion matrix shows 262 normal records flagged as anomalies and 4,917 anomalies missed as normal. That missed-attack count is an important limitation. These are benchmark results, not evidence of performance on current live networks.”
**Show:** `reports/model_comparison.png`, `reports/confusion_matrix.png`; point out false negatives.

## 3:00–4:45 — Local prototype demonstration
“Now I will run the Streamlit interface locally. I can load the included sample CSV or upload a CSV containing all 41 required input columns. The application checks for missing columns, sends records through the saved preprocessing and model pipeline, displays the predicted label and anomaly probability, and allows the result to be downloaded.”
**Show:** Run `streamlit run app/streamlit_app.py`; open the local page; load sample CSV; run predictions; show output and download. Optional API: `uvicorn app.main:app --reload --port 8000`, visit `/docs`, show `/health` and `/predict`.

## 4:45–5:45 — Testing and reproducibility
“We include automated tests for loading the model, predicting the sample CSV, checking output labels and probability bounds, and rejecting missing feature columns. The saved model pipeline preserves preprocessing and inference. MLflow is a recommended next step for recording parameters, data version, library versions, metrics, and artifacts; it is not claimed as an active tracking server.”
**Show:** `pytest -q` results and README. Show MLflow as planned only if not configured.

## 5:45–7:15 — Deployment, monitoring and maintenance
“The current demo is intended to run locally. Streamlit provides the user interface and FastAPI is an optional serving layer. Docker and cloud hosting are possible next steps, but the app is not claimed to be publicly deployed. In practice, we would monitor prediction volume, latency, application errors, anomaly-score distributions, drift, and metrics once ground-truth labels are available. New models would be trained and evaluated on versioned data, reviewed before promotion, and kept rollback-capable.”
**Show:** monitoring plan and proposed workflow: log → monitor → investigate → validate new model → approve/rollback.

## 7:15–8:15 — Security, limitations and reflection
“Safeguards include not committing credentials, limiting access to logs, minimizing sensitive data, and requiring human review. Our largest limitation is recall of 61.68%, meaning many anomalies were missed on this test split. NSL-KDD is an older benchmark, and model selection should be improved by using validation data for model selection and a separate untouched test set.”

## 8:15–8:45 — Conclusion
“This project demonstrates the model, a local prediction workflow, basic tests, and a practical deployment and maintenance plan. It is an educational prototype, not a production-ready intrusion prevention system. Next steps are stronger validation, threshold tuning, current authorized data, experiment tracking, and secure operational monitoring. Thank you.”

## Recording checklist
- Keep video under 10 minutes and below 250 MB.
- Show a real local run; do not claim a public URL if none exists.
- Keep terminal and results readable; mention the false-negative limitation.
- For group work, each member should describe a real contribution.
- Do not show secrets, private logs, or personal information.
