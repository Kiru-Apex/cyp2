from pathlib import Path
import pandas as pd
import pytest
from src.predict import FEATURES, predict_records, load_model
ROOT = Path(__file__).resolve().parents[1]
def test_model_loads(): assert load_model() is not None
def test_sample_csv_predicts():
    data = pd.read_csv(ROOT / 'sample_input.csv'); result = predict_records(data)
    assert len(result) == len(data)
    assert set(result.predicted_label.unique()).issubset({'normal','anomaly'})
    if 'anomaly_probability' in result: assert result.anomaly_probability.between(0,1).all()
def test_missing_feature_is_rejected():
    data = pd.read_csv(ROOT / 'sample_input.csv').drop(columns=[FEATURES[0]])
    with pytest.raises(ValueError, match='Missing required feature columns'): predict_records(data)
