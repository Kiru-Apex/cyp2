# AI-Based Network Intrusion Detection System (NSL-KDD)

## Project
FUSE-AI 201 Group 20 — Implementation Assignment

## Contents
- `NSL_KDD_Intrusion_Detection_Implementation.ipynb`: implementation in the required eight-task order
- `data/KDDTrain+.txt`, `data/KDDTest+.txt`: official supplied dataset splits
- `models/nsl_kdd_random_forest_pipeline.joblib`: fitted candidate model and preprocessing pipeline
- `models/nsl_kdd_logistic_regression_baseline.joblib`: fitted baseline
- `reports/Project_Report.md`: written report with measured results
- `reports/evaluation_results.json`: metrics and dataset summary
- `reports/confusion_matrix.png`, `reports/model_comparison.png`: evaluation figures
- `src/predict.py`: reusable prediction helper / CSV command-line interface
- `requirements.txt`: Python dependencies

## Setup
Recommended: Python 3.10 or newer.

```bash
python -m venv .venv
```
Activate the environment:
- Windows: `.venv\Scripts\activate`
- macOS/Linux: `source .venv/bin/activate`

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

## Run the notebook
From the project folder:

```bash
jupyter notebook NSL_KDD_Intrusion_Detection_Implementation.ipynb
```

Run the cells from top to bottom. The official train/test split is used. The notebook trains Logistic Regression and Random Forest, compares metrics, evaluates the candidate, runs edge-case checks, and saves the model.

## Use the saved model
Prepare a CSV file containing all 41 NSL-KDD input feature columns (no label or difficulty_level columns), then run:

```bash
python -m src.predict your_input.csv --output predictions.csv
```

Output contains `predicted_label` and, if supported by the model, `anomaly_probability`.

## Target labels
- `normal` = 0
- any non-normal NSL-KDD label = 1 (`anomaly`)

## Important limitations
- NSL-KDD is a benchmark dataset, not current live network traffic.
- This is a learning prototype, not a production intrusion detection deployment.
- Do not use predictions to automatically block traffic or make security decisions without independent validation.
- Add only group members who actually participated before submission.

## Module 6 prototype demo

### Streamlit user interface (local)
```bash
streamlit run app/streamlit_app.py
```
Use the included sample CSV or upload a CSV containing all 41 NSL-KDD input features. Run prediction and download results.

### Optional FastAPI endpoint
```bash
uvicorn app.main:app --reload --port 8000
```
Open `http://127.0.0.1:8000/docs` for interactive API documentation and `http://127.0.0.1:8000/health` for a health check. The `/predict` endpoint accepts a JSON object with a `records` list; each record must contain all 41 feature fields.

### Tests
```bash
pytest -q
```

### Module 6 documentation
- `reports/Monitoring_Support_Maintenance_Plan.md`: proposed monitoring, error handling, security, and retraining workflow
- `reports/Model_Card.md`: intended use, evaluation, risks, and limitations
- `reports/Module6_One_Page_Retrospective.md`: written retrospective
- `reports/Video_Presentation_Script.md`: timed capstone video outline

### Implemented vs. planned
The local Streamlit demo, optional FastAPI code, and basic tests are included. A public cloud deployment, continuous production monitoring, MLflow tracking server, and automated retraining pipeline are **not** currently configured. Do not claim these are operational unless you configure and verify them. The dataset is the existing NSL-KDD benchmark; it is not team-generated synthetic data and is not live production traffic.
