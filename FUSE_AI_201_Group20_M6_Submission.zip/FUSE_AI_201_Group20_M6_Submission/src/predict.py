"""Prediction helper for the NSL-KDD binary intrusion-detection prototype."""
from pathlib import Path
import joblib
import pandas as pd

FEATURES = [
    "duration","protocol_type","service","flag","src_bytes","dst_bytes","land","wrong_fragment","urgent",
    "hot","num_failed_logins","logged_in","num_compromised","root_shell","su_attempted","num_root",
    "num_file_creations","num_shells","num_access_files","num_outbound_cmds","is_host_login","is_guest_login",
    "count","srv_count","serror_rate","srv_serror_rate","rerror_rate","srv_rerror_rate","same_srv_rate",
    "diff_srv_rate","srv_diff_host_rate","dst_host_count","dst_host_srv_count","dst_host_same_srv_rate",
    "dst_host_diff_srv_rate","dst_host_same_src_port_rate","dst_host_srv_diff_host_rate","dst_host_serror_rate",
    "dst_host_srv_serror_rate","dst_host_rerror_rate","dst_host_srv_rerror_rate"
]
MODEL_PATH = Path(__file__).resolve().parents[1] / "models" / "nsl_kdd_random_forest_pipeline.joblib"

def load_model(model_path=MODEL_PATH):
    return joblib.load(model_path)

def predict_records(records, model=None):
    """Predict records from a DataFrame or dict/list of dicts.

    Required input columns are the 41 NSL-KDD features. Returns a DataFrame with
    predicted_label and anomaly_probability (if predict_proba is available).
    """
    model = model or load_model()
    frame = records.copy() if isinstance(records, pd.DataFrame) else pd.DataFrame(records)
    missing = [c for c in FEATURES if c not in frame.columns]
    if missing:
        raise ValueError(f"Missing required feature columns: {missing}")
    frame = frame[FEATURES]
    predictions = model.predict(frame).astype(int)
    output = pd.DataFrame({"predicted_label": ["anomaly" if x == 1 else "normal" for x in predictions]})
    if hasattr(model, "predict_proba"):
        output["anomaly_probability"] = model.predict_proba(frame)[:, 1]
    return output

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Predict normal/anomaly labels for an NSL-KDD CSV file.")
    parser.add_argument("csv_file", help="CSV containing the 41 NSL-KDD input feature columns")
    parser.add_argument("--output", default="predictions.csv", help="Output CSV path")
    args = parser.parse_args()
    result = predict_records(pd.read_csv(args.csv_file))
    result.to_csv(args.output, index=False)
    print(f"Saved {len(result)} predictions to {args.output}")
